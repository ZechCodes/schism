from sympyosis.app import App


App.launch()
