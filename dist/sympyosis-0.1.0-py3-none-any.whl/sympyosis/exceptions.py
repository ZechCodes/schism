class BaseSympyosisException(Exception):
    """Base exception for all Sympyosis exceptions."""
