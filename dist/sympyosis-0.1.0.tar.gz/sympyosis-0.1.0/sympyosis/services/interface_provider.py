from typing import Protocol


class InterfaceProvider(Protocol):
    """Protocol that all interface providers need to implement."""
